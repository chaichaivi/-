package mydiary.com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClassActivity extends AppCompatActivity {

    GridView gridView;
    SimpleAdapter simpleAdapter;
    String []title = new String[]{"日记本","项目便签","灵感随记","小帐单","写书信"};
    int[]img = new int[]{R.drawable.img01,R.drawable.img02,R.drawable.img03,R.drawable.img04,R.drawable.img05};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class);
        gridView = findViewById(R.id.classView);

        List<Map<String,Object>> list = new ArrayList<>();
        for(int i= 0;i<title.length;i++)
        {
            Map<String,Object> map = new HashMap<>();
            map.put("name",title[i]);
            map.put("img",img[i]);
            list.add(map);
        }
        simpleAdapter = new SimpleAdapter(ClassActivity.this,list
                ,R.layout.class_item,new String[]{"name","img"},new int[]{R.id.textView,R.id.imageView});

        if(simpleAdapter==null)
        {
            Log.e("simpleAdapter","create simpleAdapter failed");
            for(int i = 0;i<title.length;i++)
            {
                Log.e("error","title["+i+"]="+title[i]);
                Log.e("error","img["+i+"]="+img[i]);
                Log.e("error","simpleAdapter = "+simpleAdapter);

            }
        }

        try{


                gridView.setAdapter(simpleAdapter);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            for(int i = 0;i<title.length;i++)
            {
                Log.e("error","title["+i+"]="+title[i]);
                Log.e("error","img["+i+"]="+img[i]);
                Log.e("error","simpleAdapter = "+simpleAdapter);

            }
        }

    }
}
