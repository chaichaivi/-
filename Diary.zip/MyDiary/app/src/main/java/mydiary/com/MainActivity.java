package mydiary.com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;

import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import pl.com.salsoft.sqlitestudioremote.SQLiteStudioService;


public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private Toolbar toolbar;
    private ListView mlistview;   ////显示内容
    private int CurrItemPosition = 0;///保存当前选择的listview中的 item位置
    private EditText input_text;   ///输入框
    private MsgShowAdapter msgadapter;   ////消息显示适配
    private List<MsgItem> msglist;        //消息链表
    private MysqlliteHelper mysqlliteHelper;    /////数据库接口


    private TextView mDatePicker;  ////日期选择
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ////显示分类页
        Intent intent = new Intent();
        intent.setClass(MainActivity.this,ClassActivity.class);
        startActivity(intent);



        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("我的日记   ");
        setSupportActionBar(toolbar);
        mlistview = findViewById(R.id.msg_list);
        input_text = findViewById(R.id.input_text);
        mDatePicker = findViewById(R.id.textdate);

        msglist = new ArrayList<MsgItem>();
        msgadapter = new MsgShowAdapter(this, msglist);
        mlistview.setAdapter(msgadapter);
         mysqlliteHelper = new MysqlliteHelper(this, "/data/data/mydiary.com/diaryDB", null, 4);

        ///////测试 sqllite 数据库操作
        SQLiteStudioService.instance().start(this);

        /////初始化当日信息显示
        ///当前时间
        Date date = new Date();
        String currentDateTimeString =
                new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(date);
        UpdateOneDayData(currentDateTimeString);
        UpdateCalendarShow(date);

        /////listview 添加长按菜单
        mlistview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                    int position, long id) {
                /*
                 * arg0：发生单击事件的AdapterView
                 * arg1：AdapterView中被点击的View
                 * position：当前点击的行在adapter的下标
                 * id：当前点击的行的id
                 */
                ///保存当前选择的位置，以备后面操作，修改或删除
                CurrItemPosition = position;
                return false;
            }
        });
        /////添加长按菜单
        mlistview.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {

            @Override
            public void onCreateContextMenu(ContextMenu menu, View v,
                                            ContextMenu.ContextMenuInfo menuInfo) {
                menu.add(0, 0, 0, "修改");
                menu.add(0, 1, 0, "删除");
            }

        });
    }

      @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item
                .getMenuInfo();
        int mid = (int) info.id;// 这里的info.id对应的就是数据库中_id的值
        switch (item.getItemId()) {
            case 0:
                // 添加操作
                Toast.makeText(MainActivity.this,
                        "修改",
                        Toast.LENGTH_SHORT).show();
                break;

            case 1:
                // 删除操作
                MsgItem msg = (MsgItem)msgadapter.getItem(CurrItemPosition);
                ////更新显示
                msglist.remove(CurrItemPosition);
                msgadapter.notifyDataSetChanged();
                /////数据库中删除
                RemoveMsgByMsgId(msg.getMsgid());
                break;

            case 2:
                // 删除ALL操作
                break;

            default:
                break;
        }

        return true;
    }
    /////获取当前日期  yyyy-mm-dd
    private String GetDateStr(Date date)
    {
        Calendar cal=Calendar.getInstance();
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        String CurStr  = String.valueOf(year) + "-" + String.valueOf(month) + "-" + String.valueOf(day);
        return CurStr;
    }

    /////更新日历显示
    private void UpdateCalendarShow(Date date)
    {
        Calendar cal=Calendar.getInstance();
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        String CurStr  = String.valueOf(year) + "-" + String.valueOf(month) + "-" + String.valueOf(day);
        mDatePicker.setText(CurStr);
    }
    ///////输入框内容处理
    public void writeToDiary(View view)
    {
        if(TextUtils.isEmpty(input_text.getText().toString().trim()))
        {
            input_text.setText("");
            return;
        }
        ////如果界面显示的日期和当前的不一样，需要更新一下，返回当前
        if(!mDatePicker.getText().toString().equals(GetDateStr(new Date())))
        {
            UpdateOneDayData(new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(new Date()));
        }

        //1.写入listview
        //listview.getHasOverlappingRendering()
        MsgItem msg = new MsgItem();

        ///当前时间
        String currentDateTimeString =
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date());
        String showime = currentDateTimeString.substring(currentDateTimeString.indexOf(" "));

        msg.setMsgTime(showime);///屏幕上只显示一天时间
        ///当前位置信息
        msg.setMsgLocation("中国.深圳");////获取位置信息填充
        msg.setMsgContent(input_text.getText().toString());
        msg.setUserid(1); ///本机日记用户
        msg.setMsgtype(1); ///日记消息
        msglist.add(msg);
        msgadapter.notifyDataSetChanged();

        mlistview.setSelection(msglist.size());
        input_text.setText("");
        //2.写入数据库保存
        mysqlliteHelper.SaveMsg(msg.getMsgtype(),msg.getUserid(),msg.getMsgContent(),currentDateTimeString,msg.getMsgLocation());
        //3.同步到服务器

    }

    ////获取一天的数据，并更新到界面
    public void UpdateOneDayData(String date)
    {
        List<MsgItem> retlist = new ArrayList<MsgItem>();
        retlist = mysqlliteHelper.GetOneDayData(date);
        if(retlist.isEmpty())
        {
            ////没找到数据清空
            msglist.clear();
            msgadapter.notifyDataSetChanged();
            return;
        }
        Log.d("getdate","retlist size = "+retlist.size());
        msglist.clear();
        msglist.addAll(retlist);
        retlist.clear();
        msgadapter.notifyDataSetChanged();
        mDatePicker.setText(date);
    }
    public boolean RemoveMsgByMsgId(int msgid)
    {
        return mysqlliteHelper.Remove(msgid);
    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();

    /////连接sqlite管理用
   // public void dbmanager(View view) {
       // Intent intent = new Intent(MainActivity.this,AndroidDatabaseManager.class);
       // startActivity(intent);
    //}

    ////选择时间,导入相当数据
    public void OndateChange(View view) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);


        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                Log.d("test", "onDateSet: date: " + year + "/" + month + "/" + dayOfMonth);
                int rm = month + 1;
                //final String picking  = String.valueOf(year) + "年" + String.valueOf(rm) + "月" + String.valueOf(dayOfMonth) + "日";
                final String inputtime = String.valueOf(year) + "-" + String.valueOf(rm) + "-" + String.valueOf(dayOfMonth);
                mDatePicker.setText(inputtime);
                UpdateOneDayData(inputtime);
                Log.d("OndateChange","picking != pickedDate picking = " + inputtime +" pickedDate= "+inputtime);
            }
        };
        ////日期选择
        DatePickerDialog dialog = new DatePickerDialog(
                MainActivity.this,
                android.R.style.Theme_Holo_Dialog_MinWidth,
                mDateSetListener,
                year, month, day);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        Log.d("DatePicker" ,"On data change");

    }
}
