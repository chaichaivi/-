package mydiary.com;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

///////每次记录的消息
public class MsgItem{

    public MsgItem(){
 }
    ////保存的时候为0没有，取回的消息里面保存了服务端返回的ID
    private  int msgid =0;
    private int userid;
    private int msgtype;
    private String msgContent;
    private String msgTime;
    private String msgLocation;

    public void setMsgContent(String msgContent) {
        this.msgContent = msgContent;
    }

    public String getMsgContent() {
        return msgContent;
    }

    public String getMsgTime() {
        return msgTime;
    }

    public String getMsgLocation() {
        return msgLocation;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getUserid() {
        return userid;
    }

    public int getMsgtype() {
        return msgtype;
    }

    public void setMsgtype(int msgtype) {
        this.msgtype = msgtype;
    }

    public void setMsgTime(String msgTime) {
        this.msgTime = msgTime;
    }

    public void setMsgLocation(String msgLocation) {
        this.msgLocation = msgLocation;
    }

    public int getMsgid() {
        return msgid;
    }

    public void setMsgid(int msgid) {
        this.msgid = msgid;
    }
}
