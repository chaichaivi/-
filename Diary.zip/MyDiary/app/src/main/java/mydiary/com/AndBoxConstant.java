package mydiary.com;

enum AndBoxConstant {
    MODIFY,
    DELETE
}
