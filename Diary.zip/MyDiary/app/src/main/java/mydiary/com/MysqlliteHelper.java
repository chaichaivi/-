package mydiary.com;

import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MysqlliteHelper extends SQLiteOpenHelper {
    public MysqlliteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        datalist = new ArrayList<MsgItem>();
    }


    ///删除数据
    boolean Remove(int msgid)
    {
        try {
            SQLiteDatabase sqlDB = this.getWritableDatabase();
            String sql = "DELETE FROM msgcont WHERE msgid = " + msgid;
            Log.d("DBRemove", "remove data sql = " + sql);
            sqlDB.execSQL(sql);
            return true;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    //////返回一天的数据，根据日期
    public ArrayList<MsgItem> GetOneDayData(String date_time)
    {
        Date inputtime;
        datalist.clear();
        SimpleDateFormat formater1 = new SimpleDateFormat("yyyy-MM-dd");////取Date
        try {
            inputtime = formater1.parse(date_time);
        } catch (ParseException e) {
            e.printStackTrace();
            Log.e("MysqlliteHelper","formater1.parse failed inputstr = "+ date_time);
            return datalist;
        }
        SimpleDateFormat beginformater = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        SimpleDateFormat endformater =  new SimpleDateFormat("yyyy-MM-dd 23:59:59");

        String begintimestr = beginformater.format(inputtime);
        String endintimestr = endformater.format(inputtime);

        /////暂不考虑sql注入问题，后面优化
        String sql = "SELECT msgid,userid,msgtype,msgcontent,time(msgtime),msglocalinfo FROM msgcont WHERE msgtime >="+"'"+begintimestr+"'"+" AND msgtime < "+"'" +endintimestr+"'";

        Log.d("MysqlliteHelper","getData(sql)  begin sql = "+sql);
        ////执行SQL将结果放入list
        ArrayList<Cursor> dataResult = getData(sql);
        final Cursor c = dataResult.get(0);////结果游标
        if(c == null)
        {
            Log.d("MysqlliteHelper","no data can be return sql = "+sql);
            return datalist;
        }
        //the second cursor has error messages
        Cursor Message =dataResult.get(1);
        Message.moveToLast();
        String msg = Message.getString(0);
        Log.d("Message from sql = ",msg);

        try{
            //get data here
            c.moveToFirst();
            while(c != null && c.getCount()>0)
            {
                MsgItem retmsg = new MsgItem();
                ///msgid,userid,msgtype,msgcontent,msgtime,msglocalinfo
                retmsg.setMsgid(c.getInt(0));
                retmsg.setUserid(c.getInt(1));
                retmsg.setMsgtype(c.getInt(2));
                retmsg.setMsgContent(c.getString(3));
                retmsg.setMsgTime(c.getString(4));
                retmsg.setMsgLocation(c.getString(5));
                datalist.add(retmsg);
                c.moveToNext();
            }
            c.close();
        }catch (Exception e )
        {
            Log.e("MysqlliteHelper","get data from cursor failed "+e.toString());
            e.printStackTrace();
        }

        return datalist;
    }

    ////msgtype 消息类型 1-个人日记消息，2 --项目消息
    //userid 用户id   1-个人日消息，项目消息才会有多个，个人日记就是自己ID
    public void SaveMsg(int msgtype ,int userid,String msgcontent,String msgtime,String msglocalinfo)
    {
        ///异常后面统一再加
        SQLiteDatabase sqlDB = this.getWritableDatabase();
        ////确保表存在，看情况是否会影响性能再调整
        String sql = "CREATE TABLE IF NOT EXISTS msgcont(msgid INTEGER PRIMARY KEY AUTOINCREMENT,userid INTGER,msgtype INTGER,msgcontent VARCHAR(150),msgtime VARCHAR(20),msglocalinfo VARCHAR(20))";

        Log.d("MysqlliteHelper",sql);
        sqlDB.execSQL(sql);

        sql = "INSERT INTO msgcont(userid,msgtype,msgcontent,msgtime,msglocalinfo) VALUES ("+userid+","+msgtype+","+"'"+msgcontent+"'"+","+"'"+msgtime+"'"+","+"'"+msglocalinfo+"'"+")" ;
        Log.d("MysqlliteHelper","sql = "+sql);

        sqlDB.execSQL(sql);

    }
    public ArrayList<Cursor> getData(String Query){
        //get writable database
        SQLiteDatabase sqlDB = this.getWritableDatabase();
        String[] columns = new String[] { "message" };
        //an array list of cursor to save two cursors one has results from the query
        //other cursor stores error message if any errors are triggered
        ArrayList<Cursor> alc = new ArrayList<Cursor>(2);
        MatrixCursor Cursor2= new MatrixCursor(columns);
        alc.add(null);
        alc.add(null);

        try{
            String maxQuery = Query ;
            //execute the query results will be save in Cursor c
            Cursor c = sqlDB.rawQuery(maxQuery, null);

            //add value to cursor2
            Cursor2.addRow(new Object[] { "Success" });

            alc.set(1,Cursor2);
            if (null != c && c.getCount() > 0) {

                alc.set(0,c);
                c.moveToFirst();

                return alc ;
            }
            return alc;
        } catch(SQLException sqlEx){
            Log.d("printing exception", sqlEx.getMessage());
            //if any exceptions are triggered save the error message to cursor an return the arraylist
            Cursor2.addRow(new Object[] { ""+sqlEx.getMessage() });
            alc.set(1,Cursor2);
            return alc;
        } catch(Exception ex){
            Log.d("printing exception", ex.getMessage());

            //if any exceptions are triggered save the error message to cursor an return the arraylist
            Cursor2.addRow(new Object[] { ""+ex.getMessage() });
            alc.set(1,Cursor2);
            return alc;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    ////返回消息
    private ArrayList<MsgItem> datalist;

}
